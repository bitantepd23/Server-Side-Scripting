<!-- left column -->
      <div class='col-xs-3'>
        <h3>Links</h3>
         <ul>
                <li><a href='index.php?mode=customerList'>List of Customers</a></li>
	 </ul>
      </div>
