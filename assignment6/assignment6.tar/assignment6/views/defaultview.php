<!-- right column: content section -->

      <div class='col-xs-9'>

         <h3>Welcome to Digital Store</h3>
	 <p>Select a task from the menu</p>
     </div>
