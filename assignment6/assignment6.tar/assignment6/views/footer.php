</div>

   <div class='col-xs-12'><!-- page footer -->

    <div id='footer'>&#0169; mydigitalstore.com</div>

   </div>
