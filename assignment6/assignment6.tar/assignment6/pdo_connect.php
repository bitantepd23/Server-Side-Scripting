<?php

$user = 'NETID';
$pass = 'DB-Password'; // first initial last initial last 4-digits of ID
$db_info='mysql:host=washington.uww.edu; dbname=cs382-2171_NETID';
try {
    $db = new PDO($db_info, $user, $pass);

} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}


?>

