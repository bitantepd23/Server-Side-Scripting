<?php
     // include database connection info
     include('pdo_connect.php');
    // include functions needed to data from the database
     include('models/model.php');

    // display header
     include('views/header.php');
     
   // include menu
     include('views/sidemenu.php');

     // Read the main task using the primary key 'mode'
     $mode = '';
      if (isset($_REQUEST['mode']))
           $mode = $_REQUEST['mode'];


     switch ($mode) {
	case 'customerList' :
		// obtain a list of customers
		$dataList = getCustomerList();
		
		// include a template to display data
                include('views/customerlist.php');
		break;


        default :
                // display default view
		include('views/defaultview.php');
                break;
        }

   // include footer
    include('views/footer.php');
?>
