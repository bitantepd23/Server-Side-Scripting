<?php

 function checkValidUser(){
	// validate user
	$sql = "select client_id, first_name, last_name from clients where
		username=:username and pwd = :pwd";
	// define values for parameters
	$values = array(':username'=>$_POST['username'], ':pwd'=>md5($_POST['pwd']));
	$result = getOne($sql, $values);
	return $result;
 }
 
  function getProductList(){
	// define SQL statement
	$sql = 'select * from products ORDER BY product_type';
	$data= getAll($sql);
	return $data;
  }



  function getOne($sql, $parameter = null){
        global $db;
        $statement = $db->prepare($sql);
        // execute the SQL statement
        $statement->execute($parameter);
        // return result
        $result = $statement->fetch(PDO::FETCH_ASSOC);

        return $result;
  }


  function getAll($sql, $parameter = null){
        global $db;
        $statement = $db->prepare($sql);
        // execute the SQL statement
        $statement->execute($parameter);
        // return result
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
  }

?>
